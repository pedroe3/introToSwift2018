//
//  ViewController.swift
//  Homework1_PR
//
//  Created by Pedro Rivera on 3/31/18.
//  Copyright © 2018 Pedro Rivera. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var makerLabel: UILabel!
    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var costLabel: UILabel!
    
    @IBOutlet weak var jeepButton: UIButton!
    @IBOutlet weak var toyotaButton: UIButton!
    @IBOutlet weak var hondaButton: UIButton!
    @IBOutlet weak var nissanButton: UIButton!
    
    let jeep = Vehicle(maker:"Jeep", model:"Wrangler", cost:100.00)
    let toyota = Vehicle(maker:"Toyota", model:"Tacoma", cost:200.00)
    let honda = Vehicle(maker:"Honda", model:"Civic", cost: 300.00)
    let nissan = Vehicle(maker:"Nissan", model:"Sentra", cost:400.00)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
      
      self.setButtons()
        
    }
    
    
    func setButtons(){
    
        jeepButton.setTitle( jeep.maker, for: .normal)
        toyotaButton.setTitle(toyota.maker, for: .normal)
        hondaButton.setTitle(honda.maker, for: .normal)
        nissanButton.setTitle(nissan.maker, for: .normal)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    //todo repeated code,  class for this.!!
    @IBAction func toyotaButtonAction(_button:UIButton){
        makerLabel.text = toyota.maker
        modelLabel.text = toyota.model
        costLabel.text = String(toyota.cost)
    }
    @IBAction func nissanButtonAction(_button:UIButton){
       
        makerLabel.text = nissan.maker
        modelLabel.text = nissan.model
        costLabel.text = String(nissan.cost)
        
    }
    @IBAction func jeepButtonAction(_button:UIButton){
        makerLabel.text = jeep.maker
        modelLabel.text = jeep.model
        costLabel.text = String(jeep.cost)
    }
    @IBAction func hondaButtonAction(_button:UIButton){
        makerLabel.text = honda.maker
        modelLabel.text = honda.model
        costLabel.text = String(honda.cost)
    }
    
    
   
    

    
    
  
    
 

    
}

