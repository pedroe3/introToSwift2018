//
//  Vehicle.swift
//  Homework1_PR
//
//  Created by Pedro Rivera on 4/3/18.
//  Copyright © 2018 Pedro Rivera. All rights reserved.
//

import Foundation
import UIKit


class Vehicle {
    
    var maker: String = ""
    var model: String = ""
    var cost:Double = 0.00
    
    init(maker: String,model: String, cost: Double) {
        
    
        self.maker = maker
        self.model = model
        self.cost = cost
        
    }
    
    
}
